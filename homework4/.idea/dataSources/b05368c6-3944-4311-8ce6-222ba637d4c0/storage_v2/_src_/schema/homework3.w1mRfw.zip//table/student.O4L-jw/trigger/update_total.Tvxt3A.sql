create definer = root@localhost trigger update_total
    before insert
    on student
    for each row
BEGIN
    SET NEW.total = NEW.java + NEW.android + NEW.javaee;
END;

