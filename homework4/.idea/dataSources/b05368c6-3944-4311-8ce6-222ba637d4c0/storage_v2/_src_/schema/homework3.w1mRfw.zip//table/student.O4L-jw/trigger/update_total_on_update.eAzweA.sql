create definer = root@localhost trigger update_total_on_update
    before update
    on student
    for each row
BEGIN
    SET NEW.total = NEW.java + NEW.android + NEW.javaee;
END;

